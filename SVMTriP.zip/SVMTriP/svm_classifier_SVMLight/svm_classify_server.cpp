/***********************************************************************/
/*                                                                     */
/*   svm_classify_server.cpp                                           */
/*                                                                     */
/*   Classification server module of Support Vector Machine.           */
/*                                                                     */
/*   Author:  Thorsten Joachims                                        */
/*   Date:  02.07.02                                                   */
/*                                                                     */
/*   Modified for server version by Matt Gerber                        */
/*   Date:  03.30.10                                                    */
/*                                                                     */
/*   Copyright (c) 2002  Thorsten Joachims - All rights reserved       */
/*                                                                     */
/*   This software is available for non-commercial use only. It must   */
/*   not be modified and distributed without prior permission of the   */
/*   author. The author is not responsible for implications from the   */
/*   use of this software.                                             */
/*                                                                     */
/***********************************************************************/

#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <fstream>
#include <string>
#include "svm_common.h"

using namespace std;

void print_flush(char* msg);
void die(char* error);

int main (int argc, char* argv[])
{
  if(argc != 3)
    {
      string error = "Usage:  svm_classify_server <model> <port>\n";
      error += string("  <model>:  SVM-Light model file to use\n");
      error += string("   <port>:  port to serve classifications on\n");
      die((char*)error.c_str());
    }

  // read model
  MODEL* model=read_model(argv[1]);
  if(model->kernel_parm.kernel_type == 0)
    add_weight_vector_to_linear_model(model);

  // **************  NETWORKING SETUP  **************
  int serverSocket;                                           // socket descriptor for server
  int clientSocket;                                           // socket descriptor for client
  struct sockaddr_in serverAddress;                           // local address
  struct sockaddr_in clientAddress;                           // client address
  unsigned int clientAddressLength = sizeof(clientAddress);   // length of client address data structure
  unsigned short serverPort = atoi(argv[2]);                  // server port
  
  // create socket for incoming connections
  if ((serverSocket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
    die("Failed to init socket");
  
  // construct local address structure
  memset(&serverAddress, 0, sizeof(serverAddress));   // zero out structure
  serverAddress.sin_family = AF_INET;                 // internet address family
  serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);  // any incoming interface
  serverAddress.sin_port = htons(serverPort);         // local port
  
  // bind to the local address
  if (bind(serverSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) < 0)
    die("Failed to bind socket to local address");
  
  // mark the socket so it will listen for incoming connections
  if (listen(serverSocket, 5) < 0)
    die("Failed to start listener");
  
  printf("Serving classifications on port %i...\n", serverPort); 
  fflush(stdout);
  
  // ***** END NETWORKING SETUP *****

  // listen forever
  while(true)
    {
      // wait for a client to connect
      if ((clientSocket = accept(serverSocket, (struct sockaddr *) &clientAddress, &clientAddressLength)) < 0)
        {
	  print_flush("Failed to accept client\n");
	  continue;
        }
      
      // message received from client
      string received("");

      // receive buffer
      int buffSize = 1024;
      char buffer[buffSize];

      // read first chunk
      int recvMsgSize;               
      if ((recvMsgSize = recv(clientSocket, buffer, buffSize, 0)) < 0)
        {
	  print_flush("Failed to receive client message\n");
	  continue;
        }
      
      // continue while we're able to read data
      int error = false;
      while (recvMsgSize > 0)
        {
	  // get string for data that was read
	  string bufferStr = string(buffer, recvMsgSize);

	  // check for end of message character ('!')
	  size_t endCharLoc;
	  if((endCharLoc = bufferStr.find("!", 0)) != string::npos)
	    {
	      // clip off '!' character
	      bufferStr = bufferStr.substr(0, endCharLoc);
	    }
	      
	  // append to current string
	  received += bufferStr;
	      
	  // break if we're done
	  if(endCharLoc != string::npos)
	    break;	  
	  
	  // receive more data
	  if ((recvMsgSize = recv(clientSocket, buffer, buffSize, 0)) < 0)
            {
	      print_flush("Failed to read additional data from client\n");
	      error = true;
            }
        }
      
      if(error)
	{
	  print_flush("Failed to read instance data from client\n");
	  continue;
	}
      
      // write file to classify
      char* tempInstancesFile = "temp_to_classify";
      ofstream toClassifyFile;
      toClassifyFile.open(tempInstancesFile);
      toClassifyFile << received;
      toClassifyFile.close();

      // local variables for SVM
      DOC *doc;
      WORD *words;
      long max_docs,max_words_doc,lld;
      long totdoc=0,queryid,slackid;
      long correct=0,incorrect=0,no_accuracy=0;
      long res_a=0,res_b=0,res_c=0,res_d=0,wnum,pred_format;
      long j;
      double t1,runtime=0;
      double dist,doc_label,costfactor;
      char *comment; 
      FILE *predfl;
      FILE *doc_file;
      char *predictionsfile = "temp_predictions";
      
      // default format
      pred_format = 1;

      // scan size of input file      
      nol_ll(tempInstancesFile,&max_docs,&max_words_doc,&lld);
      max_words_doc+=2;
      lld+=2;
      
      // allocate memory
      char* line = (char *)my_malloc(sizeof(char)*lld);
      words = (WORD *)my_malloc(sizeof(WORD)*(max_words_doc+10));
      
      // open instances for reading
      if ((doc_file = fopen (tempInstancesFile, "r")) == NULL)
        {
	  print_flush("Failed to open instances file for reading\n");
	  continue;
        }
      
      // open predictions file for writing
      if ((predfl = fopen (predictionsfile, "w")) == NULL)
        {
	  print_flush("Failed to open predictions file for writing\n");
	  continue;
        }      
      

      while((!feof(doc_file)) && fgets(line,(int)lld,doc_file))
        {
	  // check if line starts with comment
	  if(line[0] == '#') 
	    continue;  
	  
	  parse_document(line,words,&doc_label,&queryid,&slackid,&costfactor,&wnum,max_words_doc,&comment);
	  totdoc++;
	  if(model->kernel_parm.kernel_type == 0) 
            {  
	      // linear kernel
	      for(j=0;(words[j]).wnum != 0;j++) 
                {  
		  // check if feature numbers are not larger than in model, remove if necessary
		  if((words[j]).wnum>model->totwords) 
		    (words[j]).wnum=0;              
                }                                       
	      
	      doc = create_example(-1,0,0,0.0,create_svector(words,comment,1.0));
	      t1=get_runtime();
	      dist=classify_example_linear(model,doc);
	      runtime+=(get_runtime()-t1);
	      free_example(doc,1);
            }
	  else 
            {                             
	      // non-linear kernel
	      doc = create_example(-1,0,0,0.0,create_svector(words,comment,1.0));
	      t1=get_runtime();
	      dist=classify_example(model,doc);
	      runtime+=(get_runtime()-t1);
	      free_example(doc,1);
            }
	  
	  if(dist>0) 
            {
	      // old weird output format
	      if(pred_format==0) 
		fprintf(predfl,"%.8g:+1 %.8g:-1\n",dist,-dist);
	      
	      if(doc_label>0) 
		correct++; 
	      else 
		incorrect++;
	      
	      if(doc_label>0) 
		res_a++; 
	      else 
		res_b++;
            }
	  else 
            {
	      // old weired output format
	      if(pred_format==0)
		fprintf(predfl,"%.8g:-1 %.8g:+1\n",-dist,dist);
	      
	      if(doc_label<0) 
		correct++; 
	      else 
		incorrect++;
	      
	      if(doc_label>0) 
		res_c++; 
	      else 
		res_d++;
            }
	  
	  if(pred_format==1) 
            { 
	      /* output the value of decision function */
	      fprintf(predfl,"%.8g\n",dist);
            }
	  
	  if((int)(0.01+(doc_label*doc_label)) != 1) 
            { 
	      /* test data is not binary labeled */
	      no_accuracy=1;
            }
        }      

      // close files
      fclose(doc_file);
      fclose(predfl);

      // read predictions file
      ifstream predFile;
      predFile.open(predictionsfile);
      if(!predFile)
	{
	  print_flush("Failed to read predictions file\n");
	  continue;
	}

      string predictions("");
      string prediction;
      while(getline(predFile, prediction))
	predictions += prediction + "\n";

      predFile.close();

      // send message back to client
      int predictionsLen = predictions.length();
      if (send(clientSocket, predictions.c_str(), predictionsLen, 0) != predictionsLen)
        {
	  print_flush("Failed to send response");
	  continue;
        }
      
      // close client connection
      close(clientSocket);
      
      free(line);
      free(words);
      remove(tempInstancesFile);
      remove(predictionsfile);

    }

  return 1;
}

void print_flush(char* msg)
{
  printf(msg);
  fflush(stdout);
}

void die(char* error)
{
  print_flush(error);
  exit(0);
}
