
/***********************************************************************/
/*                                                                     */
/*   Classification server module of Support Vector Machine.           */
/*                                                                     */
/*   Author:  Thorsten Joachims                                        */
/*   Date:  02.07.02                                                   */
/*                                                                     */
/*   Modified for server version by Matt Gerber                        */
/*   Date:  11.19.07                                                   */
/*                                                                     */
/*   Copyright (c) 2002  Thorsten Joachims - All rights reserved       */
/*                                                                     */
/*   This software is available for non-commercial use only. It must   */
/*   not be modified and distributed without prior permission of the   */
/*   author. The author is not responsible for implications from the   */
/*   use of this software.                                             */
/*                                                                     */
/***********************************************************************/

Purpose
=======
This modification of the standard svm_classify module runs in "server mode",
meaning it loads a model once and serves classifications from the loaded model
without having to reload the model each time. This can dramatically reduce
processing time in large-scale learning tasks that use large models.


Compilation
===========
Execute the `make' command in the main directory


Execution
=========
The module uses the following command line invocation:

svm_classify_server <model> <port>

where <model> is the model to serve classifications for, and <port> is the TCP
port to serve those classifications on.


Communication
=============
To call the classification server, establish a TCP connection to it on the
given port. Next, write the test instance file (as specified at
http://svmlight.joachims.org) followed by a '!'. The server will send back the
predictions file.

'\n' should be used for all end-line sequences.


Questions/comments
==================
Email gerberm2@msu.edu
