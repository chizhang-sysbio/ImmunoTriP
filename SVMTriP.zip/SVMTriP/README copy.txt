Instructions ;


This package was developed by Kosmas Galanis <kosmasgal@gmail.com> in 2017 based on the original SVMTrip web-server developed by Dr. Bo Yao .
   


1. Make the svm_classify_server executable for your system(the one included is tested for Linux Mint)
2. Execute the svm_classify_server putting the model to load and and open port --> e.g. ./svm_classify_server model_20aa.dat 8000
3. Change the paths for SVMTrip.pl and Createtestdata.pl
4. Change the the IP and Port variables in "predict.py" to the correct values(not sure if 'localhost' works instead of the IP).
5. should also change the path of "GetTopPredictions.pl"
6. And execute the SVMTrip.pl normally for the model loaded


Changes to the stock scripts !!

 